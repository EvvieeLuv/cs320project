import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("123", "Test Task", "This is a test description.");
        assertEquals("123", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test description.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Test", "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test", "Desc");
        });
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", null, "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "ThisNameIsWayTooLongToBeValid", "Desc");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Name", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Name", "This description is way too long and should definitely fail validation.");
        });
    }

    @Test
    public void testSetters() {
        Task task = new Task("1", "Name", "Desc");
        task.setName("Updated");
        task.setDescription("Updated Description");
        assertEquals("Updated", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }
}
