import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    public void setup() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "Task1", "Description1");
        taskService.addTask(task);
        assertEquals("Task1", taskService.getTask("1").getName());
    }

    @Test
    public void testAddDuplicateTaskId() {
        Task task1 = new Task("1", "Task1", "Description1");
        Task task2 = new Task("1", "Task2", "Description2");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("1", "Task1", "Description1");
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    public void testDeleteNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("99"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("1", "Task1", "Description1");
        taskService.addTask(task);
        taskService.updateTaskName("1", "UpdatedName");
        assertEquals("UpdatedName", taskService.getTask("1").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("1", "Task1", "Description1");
        taskService.addTask(task);
        taskService.updateTaskDescription("1", "UpdatedDescription");
        assertEquals("UpdatedDescription", taskService.getTask("1").getDescription());
    }

    @Test
    public void testUpdateNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("99", "NewName"));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("99", "NewDesc"));
    }
}
