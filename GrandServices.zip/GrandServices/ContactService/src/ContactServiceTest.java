import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "Address");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("002", "Alice", "Smith", "1112223333", "Address");
        service.addContact(contact);
        service.deleteContact("002");
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("002"));
    }

    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("003", "Bob", "Jones", "2223334444", "Some Address");
        service.addContact(contact);
        service.updateFirstName("003", "Bobby");
        assertEquals("Bobby", contact.getFirstName());
    }

    @Test
    public void testUpdateAllFields() {
        Contact contact = new Contact("004", "Tom", "Lee", "3334445555", "Old Address");
        service.addContact(contact);

        service.updateLastName("004", "Li");
        service.updatePhone("004", "9998887777");
        service.updateAddress("004", "New Address");

        assertEquals("Li", contact.getLastName());
        assertEquals("9998887777", contact.getPhone());
        assertEquals("New Address", contact.getAddress());
    }
}
