import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import java.util.Calendar;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        appointment = new Appointment("001", getFutureDate(), "Consultation");
        service.addAppointment(appointment);
    }

    @Test
    void testAddAppointment() {
        Appointment newAppt = new Appointment("002", getFutureDate(), "Dental Cleaning");
        service.addAppointment(newAppt);
        assertEquals(newAppt, service.getAppointment("002"));
    }

    @Test
    void testAddDuplicateId() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment));
    }

    @Test
    void testDeleteAppointment() {
        service.deleteAppointment("001");
        assertNull(service.getAppointment("001"));
    }

    @Test
    void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("999"));
    }

    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 2);
        return calendar.getTime();
    }
}
