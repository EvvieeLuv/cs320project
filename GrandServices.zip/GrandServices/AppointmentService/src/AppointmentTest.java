import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import java.util.Calendar;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    void testValidAppointment() {
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment("123", futureDate, "Check-up");
        assertEquals("123", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Check-up", appointment.getDescription());
    }

    @Test
    void testInvalidAppointmentId() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Test"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Test"));
    }

    @Test
    void testInvalidDate() {
        Date pastDate = getPastDate();
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", pastDate, "Test"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", null, "Test"));
    }

    @Test
    void testInvalidDescription() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("123", futureDate, "This is a very long description that exceeds the 50 characters limit."));
    }

    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        return calendar.getTime();
    }

    private Date getPastDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        return calendar.getTime();
    }
}
